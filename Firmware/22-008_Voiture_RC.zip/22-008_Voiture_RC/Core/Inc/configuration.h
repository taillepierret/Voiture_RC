/*
 * configuration.h
 *
 *  Created on: Sep 19, 2023
 *      Author: teddy
 */

#ifndef INC_CONFIGURATION_H_
#define INC_CONFIGURATION_H_


#define cVersion_FIRMWARE (char*) "V01.00.00"


#endif /* INC_CONFIGURATION_H_ */

/*
 * tools.h
 *
 *  Created on: Sep 18, 2023
 *      Author: teddy
 */

#ifndef INC_TOOLS_H_
#define INC_TOOLS_H_








#endif /* INC_TOOLS_H_ */

/*
 * tools.c
 *
 *  Created on: Sep 18, 2023
 *      Author: teddy
 */

#include "tools.h"








